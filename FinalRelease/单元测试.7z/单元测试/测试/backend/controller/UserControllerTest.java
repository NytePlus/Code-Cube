package com.example.backend.controller;

import com.example.backend.DTOs.GetRepoDTO;
import com.example.backend.DTOs.UserDTO;
import com.example.backend.domains.User;
import com.example.backend.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
    }

    @Test
    void checkAccountHandler_ShouldReturnTrue_WhenUserServiceReturnsTrue() throws Exception {
        when(userService.checkAccount(any(UserDTO.class))).thenReturn(true);

        mockMvc.perform(post("/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"user\",\"password\":\"pass\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void signUpHandler_ShouldReturnTrue_WhenUserServiceReturnsTrue() throws Exception {
        when(userService.signUp(any(UserDTO.class))).thenReturn(true);

        mockMvc.perform(post("/signup")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"user\",\"password\":\"pass\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void isStarredByUserHandler_ShouldReturnTrue_WhenUserServiceReturnsTrue() throws Exception {
        when(userService.checkStarByPath(any(GetRepoDTO.class))).thenReturn(true);

        mockMvc.perform(post("/repoStarCheck")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"user\":\"user\",\"repo\":\"repo\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void changeAvatarHandler_ShouldReturnTrue() throws Exception {
        when(userService.changeAvatar(any(HttpServletRequest.class), anyString())).thenReturn(true);

        mockMvc.perform(post("/avatar")
                        .param("userId", "user"))
                .andExpect(status().isOk());
    }

    @Test
    void getProfileHandler_ShouldReturnUser() throws Exception {
        User user = new User();
        when(userService.getProfile(anyString())).thenReturn(user);

        mockMvc.perform(get("/user")
                        .param("name", "user"))
                .andExpect(status().isOk());
    }

    @Test
    void changeIntroductionHandler_ShouldReturnTrue() throws Exception {
        when(userService.changeIntroduction(anyString(), anyString())).thenReturn(true);

        mockMvc.perform(post("/introduction")
                        .param("introduction", "new intro"))
                .andExpect(status().isOk());
    }

    @Test
    void getUserByName_ShouldReturnUser_WhenUserExists() throws Exception {
        User user = new User();
        when(userService.getUserByName(anyString())).thenReturn(user);

        mockMvc.perform(get("/name/{name}", "user"))
                .andExpect(status().isOk());
    }

    @Test
    void getUserByName_ShouldReturnNotFound_WhenUserDoesNotExist() throws Exception {
        when(userService.getUserByName(anyString())).thenReturn(null);

        mockMvc.perform(get("/name/{name}", "user"))
                .andExpect(status().isNotFound());
    }
}
