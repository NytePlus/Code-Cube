package com.example.backend.controller;

import com.example.backend.domains.Comment;
import com.example.backend.domains.Discussion;
import com.example.backend.serviceImpl.ForumServiceImpl;
import com.example.backend.utils.SessionUtils;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(DiscussionController.class)
class DiscussionControllerTest {

    @MockBean
    private ForumServiceImpl forumServiceImpl;

    @InjectMocks
    private DiscussionController discussionController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(discussionController).build();
    }

    @Test
    void testGetAllComments() throws Exception {
        Integer discussionId = 1;
        List<Comment> comments = Arrays.asList(new Comment(), new Comment());
        when(forumServiceImpl.getCommentByDiscussion(discussionId)).thenReturn(comments);

        mockMvc.perform(get("/api/discussions/{discussionId}/comments", discussionId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$").isNotEmpty());

        verify(forumServiceImpl, times(1)).getCommentByDiscussion(discussionId);
    }

    @Test
    void testGetDiscussionsByUserId() throws Exception {
        Integer userId = 1;
        List<Discussion> discussions = Arrays.asList(new Discussion(), new Discussion());
        when(forumServiceImpl.getDiscussionsByUserId(userId)).thenReturn(discussions);

        mockMvc.perform(get("/api/discussions/user/{userId}", userId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$").isNotEmpty());

        verify(forumServiceImpl, times(1)).getDiscussionsByUserId(userId);
    }

    @Test
    void testGetDiscussionsByUserName() throws Exception {
        String name = "user";
        List<Discussion> discussions = Arrays.asList(new Discussion(), new Discussion());
        when(forumServiceImpl.getDiscussionsByUserName(name)).thenReturn(discussions);

        mockMvc.perform(get("/api/discussions/{name}", name))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$").isNotEmpty());

        verify(forumServiceImpl, times(1)).getDiscussionsByUserName(name);
    }

    @Test
    void testCreateDiscussion() throws Exception {
        String name = "user";
        String title = "Test title";
        Discussion discussion = new Discussion();
        when(forumServiceImpl.createDiscussion(name, title)).thenReturn(discussion);

        mockMvc.perform(post("/api/discussions/create")
                        .param("name", name)
                        .param("title", title))
                .andExpect(status().isOk());

        verify(forumServiceImpl, times(1)).createDiscussion(name, title);
    }

    @Test
    void testGetCommentsByDate() throws Exception {
        Integer discussionId = 1;
        String date = "2023-06-01";
        Date parsedDate = new SimpleDateFormat("yyyy-MM-dd").parse(date);
        List<Comment> comments = Arrays.asList(new Comment(), new Comment());
        when(forumServiceImpl.getCommentsByDate(discussionId, parsedDate)).thenReturn(comments);

        mockMvc.perform(get("/api/discussions/{discussionId}/comments/date", discussionId)
                        .param("date", date))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$").isNotEmpty());

        verify(forumServiceImpl, times(1)).getCommentsByDate(discussionId, parsedDate);
    }

    @Test
    void testGetCommentsByDateRange() throws Exception {
        Integer discussionId = 1;
        String startDate = "2023-06-01";
        String endDate = "2023-06-10";
        Date parsedStartDate = new SimpleDateFormat("yyyy-MM-dd").parse(startDate);
        Date parsedEndDate = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
        List<Comment> comments = Arrays.asList(new Comment(), new Comment());
        when(forumServiceImpl.getCommentsByDateRange(discussionId, parsedStartDate, parsedEndDate)).thenReturn(comments);

        mockMvc.perform(get("/api/discussions/{discussionId}/comments/date-range", discussionId)
                        .param("startDate", startDate)
                        .param("endDate", endDate))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$").isNotEmpty());

        verify(forumServiceImpl, times(1)).getCommentsByDateRange(discussionId, parsedStartDate, parsedEndDate);
    }

    @Test
    void testGetLastCommentDateByDiscussion() throws Exception {
        Integer discussionId = 1;
        Date lastDate = new Date();
        Comment lastComment = new Comment();
        lastComment.setDate(lastDate);
        when(forumServiceImpl.getLastCommentByDiscussion(discussionId)).thenReturn(lastComment);

        mockMvc.perform(get("/api/discussions/{discussionId}/comments/last", discussionId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isNotEmpty());

        verify(forumServiceImpl, times(1)).getLastCommentByDiscussion(discussionId);
    }

    @Test
    void testGetAllDiscussions() throws Exception {
        List<Discussion> discussions = Arrays.asList(new Discussion(), new Discussion());
        when(forumServiceImpl.getAllDiscussions()).thenReturn(discussions);

        mockMvc.perform(get("/api/discussions/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$").isNotEmpty());

        verify(forumServiceImpl, times(1)).getAllDiscussions();
    }
}
