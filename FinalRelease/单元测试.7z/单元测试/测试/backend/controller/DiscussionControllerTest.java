package com.example.backend.controller;

import com.example.backend.domains.Comment;
import com.example.backend.domains.Discussion;
import com.example.backend.serviceImpl.ForumServiceImpl;
import com.example.backend.utils.SessionUtils;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

public class DiscussionControllerTest {

    @Mock
    private ForumServiceImpl forumServiceImpl;

    @InjectMocks
    private DiscussionController discussionController;

    @Mock
    private HttpSession session;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllComments() {
        List<Comment> comments = new ArrayList<>();
        when(forumServiceImpl.getCommentByDiscussion(anyInt())).thenReturn(comments);

        ResponseEntity<List<Comment>> response = discussionController.getAllComments(1);

        assertEquals(comments, response.getBody());
        verify(forumServiceImpl, times(1)).getCommentByDiscussion(1);
    }




    @Test
    void testGetDiscussionsByUserId() {
        List<Discussion> discussions = new ArrayList<>();
        when(forumServiceImpl.getDiscussionsByUserId(anyInt())).thenReturn(discussions);

        ResponseEntity<List<Discussion>> response = discussionController.getDiscussionsByUserId(1);

        assertEquals(discussions, response.getBody());
        verify(forumServiceImpl, times(1)).getDiscussionsByUserId(1);
    }

    @Test
    void testGetDiscussionsByUserName() {
        List<Discussion> discussions = new ArrayList<>();
        when(forumServiceImpl.getDiscussionsByUserName(anyString())).thenReturn(discussions);

        ResponseEntity<List<Discussion>> response = discussionController.getDiscussionsByUserName("John");

        assertEquals(discussions, response.getBody());
        verify(forumServiceImpl, times(1)).getDiscussionsByUserName("John");
    }

    @Test
    void testCreateDiscussion() {
        Discussion discussion = new Discussion();
        when(forumServiceImpl.createDiscussion(anyString(), anyString())).thenReturn(discussion);

        ResponseEntity<Discussion> response = discussionController.createDiscussion("John", "Test Title");

        assertEquals(discussion, response.getBody());
        verify(forumServiceImpl, times(1)).createDiscussion("John", "Test Title");
    }

    @Test
    void testGetCommentsByDate() throws ParseException {
        List<Comment> comments = new ArrayList<>();
        when(forumServiceImpl.getCommentsByDate(anyInt(), any(Date.class))).thenReturn(comments);

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String date = "2024-06-20";
        Date parsedDate = formatter.parse(date);

        ResponseEntity<List<Comment>> response = discussionController.getCommentsByDate(1, date);

        assertEquals(comments, response.getBody());
        verify(forumServiceImpl, times(1)).getCommentsByDate(1, parsedDate);
    }

    @Test
    void testGetCommentsByDateRange() throws ParseException {
        List<Comment> comments = new ArrayList<>();
        when(forumServiceImpl.getCommentsByDateRange(anyInt(), any(Date.class), any(Date.class))).thenReturn(comments);

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String startDate = "2024-06-20";
        String endDate = "2024-06-21";
        Date parsedStartDate = formatter.parse(startDate);
        Date parsedEndDate = formatter.parse(endDate);

        ResponseEntity<List<Comment>> response = discussionController.getCommentsByDateRange(1, startDate, endDate);

        assertEquals(comments, response.getBody());
        verify(forumServiceImpl, times(1)).getCommentsByDateRange(1, parsedStartDate, parsedEndDate);
    }

    @Test
    void testGetLastCommentDateByDiscussion() {
        Comment comment = new Comment();
        comment.setDate(new Date());
        when(forumServiceImpl.getLastCommentByDiscussion(anyInt())).thenReturn(comment);

        ResponseEntity<Date> response = discussionController.getLastCommentDateByDiscussion(1);

        assertEquals(comment.getDate(), response.getBody());
        verify(forumServiceImpl, times(1)).getLastCommentByDiscussion(1);
    }

    @Test
    void testGetLastCommentDateByDiscussionNoContent() {
        when(forumServiceImpl.getLastCommentByDiscussion(anyInt())).thenReturn(null);

        ResponseEntity<Date> response = discussionController.getLastCommentDateByDiscussion(1);

        assertEquals(204, response.getStatusCodeValue());
        verify(forumServiceImpl, times(1)).getLastCommentByDiscussion(1);
    }

    @Test
    void testGetAllDiscussions() {
        List<Discussion> discussions = new ArrayList<>();
        when(forumServiceImpl.getAllDiscussions()).thenReturn(discussions);

        ResponseEntity<List<Discussion>> response = discussionController.getAllDiscussions();

        assertEquals(discussions, response.getBody());
        verify(forumServiceImpl, times(1)).getAllDiscussions();
    }
}
