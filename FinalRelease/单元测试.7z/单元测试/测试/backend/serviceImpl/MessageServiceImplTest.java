package com.example.backend.serviceImpl;

import com.example.backend.domains.Conversation;
import com.example.backend.domains.Message;
import com.example.backend.domains.User;
import com.example.backend.repository.ConversationRepo;
import com.example.backend.repository.MessageRepo;
import com.example.backend.repository.UserConversationRepository;
import com.example.backend.repository.UserRepo;
import com.example.backend.service.MessageService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MessageServiceImplTest {

    @Mock
    private MessageRepo messageRepo;

    @Mock
    private UserConversationRepository userConversationRepo;

    @Mock
    private UserRepo userRepo;

    @Mock
    private ConversationRepo conversationRepo;

    @InjectMocks
    private MessageServiceImpl messageService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetMessagesByConversationId() {
        Integer conversationId = 1;
        List<Message> messages = Arrays.asList(new Message(), new Message());
        when(messageRepo.findByConversationId(conversationId)).thenReturn(messages);

        List<Message> result = messageService.getMessagesByConversationId(conversationId);

        assertEquals(messages, result);
        verify(messageRepo, times(1)).findByConversationId(conversationId);
    }

    @Test
    void testPostMessage() {
        Integer userId = 1;
        Integer conversationId = 1;
        String content = "Hello, world!";
        User user = new User();
        Conversation conversation = new Conversation();
        when(userRepo.findById(userId)).thenReturn(Optional.of(user));
        when(conversationRepo.findById(conversationId)).thenReturn(Optional.of(conversation));
        Message message = new Message();
        when(messageRepo.save(any(Message.class))).thenReturn(message);

        Message result = messageService.postMessage(userId, conversationId, content);

        assertNotNull(result);
        assertEquals(null, result.getContent());
        verify(messageRepo, times(1)).save(any(Message.class));
    }

    @Test
    void testGetConversationsByUserId() {
        Integer userId = 1;
        List<Conversation> conversations = Arrays.asList(new Conversation(), new Conversation());
        when(conversationRepo.findByUserId(userId)).thenReturn(conversations);

        List<Conversation> result = messageService.getConversationsByUserId(userId);

        assertEquals(conversations, result);
        verify(conversationRepo, times(1)).findByUserId(userId);
    }

    @Test
    void testGetConversationsByUserName() {
        String name = "testUser";
        List<Conversation> conversations = Arrays.asList(new Conversation(), new Conversation());
        when(conversationRepo.findByName(name)).thenReturn(conversations);

        List<Conversation> result = messageService.getConversationsByUserName(name);

        assertEquals(conversations, result);
        verify(conversationRepo, times(1)).findByName(name);
    }

    @Test
    void testCreateConversation() {
        String currentUserName = "user1";
        String otherUserName = "user2";
        User user1 = new User();
        User user2 = new User();
        when(userRepo.findByName(currentUserName)).thenReturn(user1);
        when(userRepo.findByName(otherUserName)).thenReturn(user2);
        Conversation conversation = new Conversation();
        when(conversationRepo.save(any(Conversation.class))).thenReturn(conversation);

        Conversation result = messageService.createConversation(currentUserName, otherUserName);

        assertNotNull(result);
        verify(conversationRepo, times(1)).save(any(Conversation.class));
        verify(userRepo, times(1)).save(user1);
        verify(userRepo, times(1)).save(user2);
    }

    @Test
    void testGetLastMessageByConversationId() {
        Integer conversationId = 1;
        Message message = new Message();
        when(messageRepo.findTopByConversationIdOrderByDateDesc(conversationId)).thenReturn(message);

        Message result = messageService.getLastMessageByConversationId(conversationId);

        assertEquals(message, result);
        verify(messageRepo, times(1)).findTopByConversationIdOrderByDateDesc(conversationId);
    }
}
