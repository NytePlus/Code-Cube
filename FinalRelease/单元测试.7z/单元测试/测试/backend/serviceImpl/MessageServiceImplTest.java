package com.example.backend.serviceImpl;

import com.example.backend.domains.Conversation;
import com.example.backend.domains.Message;
import com.example.backend.domains.User;
import com.example.backend.repository.ConversationRepo;
import com.example.backend.repository.MessageRepo;
import com.example.backend.repository.UserConversationRepository;
import com.example.backend.repository.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class MessageServiceImplTest {

    @Mock
    private MessageRepo messageRepo;

    @Mock
    private UserConversationRepository userConversationRepo;

    @Mock
    private UserRepo userRepo;

    @Mock
    private ConversationRepo conversationRepo;

    @InjectMocks
    private MessageServiceImpl messageService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getMessagesByConversationId() {
        List<Message> messages = List.of(new Message());
        when(messageRepo.findByConversationId(anyInt())).thenReturn(messages);

        List<Message> result = messageService.getMessagesByConversationId(1);

        assertEquals(messages, result);
        verify(messageRepo, times(1)).findByConversationId(1);
    }

    @Test
    void postMessage() {
        User user = new User();
        Conversation conversation = new Conversation();
        Message message = new Message();
        when(userRepo.findById(anyInt())).thenReturn(Optional.of(user));
        when(conversationRepo.findById(anyInt())).thenReturn(Optional.of(conversation));
        when(messageRepo.save(any(Message.class))).thenReturn(message);

        Message result = messageService.postMessage(1, 1, "Test content");

        assertEquals(message, result);
        verify(userRepo, times(1)).findById(1);
        verify(conversationRepo, times(1)).findById(1);
        verify(messageRepo, times(1)).save(any(Message.class));
    }

    @Test
    void postMessage_UserNotFound() {
        when(userRepo.findById(anyInt())).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> messageService.postMessage(1, 1, "Test content"));
        verify(userRepo, times(1)).findById(1);
    }

    @Test
    void postMessage_ConversationNotFound() {
        User user = new User();
        when(userRepo.findById(anyInt())).thenReturn(Optional.of(user));
        when(conversationRepo.findById(anyInt())).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> messageService.postMessage(1, 1, "Test content"));
        verify(userRepo, times(1)).findById(1);
        verify(conversationRepo, times(1)).findById(1);
    }

    @Test
    void getConversationsByUserId() {
        List<Conversation> conversations = List.of(new Conversation());
        when(conversationRepo.findByUserId(anyInt())).thenReturn(conversations);

        List<Conversation> result = messageService.getConversationsByUserId(1);

        assertEquals(conversations, result);
        verify(conversationRepo, times(1)).findByUserId(1);
    }

    @Test
    void getConversationsByUserName() {
        List<Conversation> conversations = List.of(new Conversation());
        when(conversationRepo.findByName(anyString())).thenReturn(conversations);

        List<Conversation> result = messageService.getConversationsByUserName("John");

        assertEquals(conversations, result);
        verify(conversationRepo, times(1)).findByName("John");
    }

    @Test
    void createConversation() {
        User user1 = new User();
        User user2 = new User();
        Conversation conversation = new Conversation();
        when(userRepo.findByName("User1")).thenReturn(user1);
        when(userRepo.findByName("User2")).thenReturn(user2);
        when(conversationRepo.save(any(Conversation.class))).thenReturn(conversation);
        when(userRepo.save(any(User.class))).thenReturn(user1);

        Conversation result = messageService.createConversation("User1", "User2");

        assertEquals(conversation, result);
        verify(userRepo, times(1)).findByName("User1");
        verify(userRepo, times(1)).findByName("User2");
        verify(conversationRepo, times(1)).save(any(Conversation.class));
        verify(userRepo, times(2)).save(any(User.class));
    }

    @Test
    void getLastMessageByConversationId() {
        Message message = new Message();
        when(messageRepo.findTopByConversationIdOrderByDateDesc(anyInt())).thenReturn(message);

        Message result = messageService.getLastMessageByConversationId(1);

        assertEquals(message, result);
        verify(messageRepo, times(1)).findTopByConversationIdOrderByDateDesc(1);
    }
}
