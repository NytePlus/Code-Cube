package com.example.backend.serviceImpl;

import com.example.backend.DTOs.CreateRepoDTO;
import com.example.backend.DTOs.GetRepoDTO;
import com.example.backend.DTOs.NameDateLabelUserDTO;
import com.example.backend.DTOs.UserDTO;
import com.example.backend.dao.FileDao;
import com.example.backend.dao.FolderDao;
import com.example.backend.dao.RepoDao;
import com.example.backend.dao.UserDao;
import com.example.backend.domains.File;
import com.example.backend.domains.Folder;
import com.example.backend.domains.Repo;
import com.example.backend.domains.User;
import com.example.backend.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.sql.rowset.serial.SerialBlob;
import java.io.*;
import java.nio.file.*;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class RepoServiceImplTest {

    @Mock
    private RepoDao repoDao;

    @Mock
    private FileDao fileDao;

    @Mock
    private FolderDao folderDao;

    @Mock
    private UserService userService;

    @Mock
    private UserDao userDao;

    @InjectMocks
    private RepoServiceImpl repoService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFileUpload() throws Exception {
        HttpServletRequest request = mock(MultipartHttpServletRequest.class);
        MultipartFile file = new MockMultipartFile("file", "test.txt", "text/plain", "Test content".getBytes());

        when(((MultipartHttpServletRequest) request).getFiles("file")).thenReturn(List.of(file));
        when(((MultipartHttpServletRequest) request).getParameterValues("user")).thenReturn(new String[]{"user1"});
        when(((MultipartHttpServletRequest) request).getParameterValues("repo")).thenReturn(new String[]{"repo1"});
        when(((MultipartHttpServletRequest) request).getParameterValues("path")).thenReturn(new String[]{"path/to/file"});

        when(folderDao.findOrCreateByPath(anyString())).thenReturn(new Folder());

        String response = repoService.fileUpload(request);

        assertEquals("upload successful", response);
        verify(fileDao, times(1)).addFile(any(File.class));
    }

    @Test
    void testGetRepo() {
        GetRepoDTO repoDTO = new GetRepoDTO();
        repoDTO.setUserDTO(new UserDTO("user1", "password1"));
        repoDTO.setPath("path/to/repo");

        when(userService.checkAccount(any(UserDTO.class))).thenReturn(true);
        when(repoDao.findByPath(anyString())).thenReturn(new Repo());

        Repo response = repoService.getRepo(repoDTO);

        assertNull(response);
         }

    @Test
    void testGetFolder() {
        GetRepoDTO repoDTO = new GetRepoDTO();
        repoDTO.setUserDTO(new UserDTO("user1", "password1"));
        repoDTO.setPath("path/to/folder");

        when(userService.checkAccount(any(UserDTO.class))).thenReturn(true);
        when(folderDao.findByPath(anyString())).thenReturn(new Folder());

        Folder response = repoService.getFolder(repoDTO);

        assertNotNull(response);
        verify(folderDao, times(1)).findByPath("path/to/folder");
    }

    @Test
    void testGetAllPublicRepos() {
        List<Repo> repoList = new ArrayList<>();
        when(repoDao.findAllPublic()).thenReturn(repoList);

        List<Repo> response = repoService.getAllPublicRepos();

        assertEquals(repoList, response);
        verify(repoDao, times(1)).findAllPublic();
    }

    @Test
    void testGetAllByUser() {
        User user = new User();
        when(userDao.getByName(anyString())).thenReturn(user);
        List<Repo> repoList = new ArrayList<>();
        when(repoDao.findAllByUser(any(User.class))).thenReturn(repoList);

        List<Repo> response = repoService.getAllByUser("user1");

        assertEquals(repoList, response);
        verify(repoDao, times(1)).findAllByUser(user);
    }

    @Test
    void testCreateRepo() {
        CreateRepoDTO repoDTO = new CreateRepoDTO();
        when(repoDao.createByRepoDTO(any(CreateRepoDTO.class))).thenReturn(new Repo());
        when(userService.checkAccount(any(UserDTO.class))).thenReturn(true);

        Boolean response = repoService.createRepo(repoDTO);

        assertFalse(response);
    }

    @Test
    void testChangeStar() {
        GetRepoDTO repoDTO = new GetRepoDTO();
        when(userService.checkAccount(any(UserDTO.class))).thenReturn(true);
        when(repoDao.findByPath(anyString())).thenReturn(new Repo());

        Boolean response = repoService.changeStar(repoDTO);

        assertFalse(response);
    }

    @Test
    void testGetRepoByNameDateLabelUser() {
        NameDateLabelUserDTO nameDateLabelUserDTO = new NameDateLabelUserDTO();
        List<Repo> repoList = new ArrayList<>();
        when(repoDao.getRepoByNameDateLabelUser(anyString(), anyString(), anyString(), anyList(), anyString())).thenReturn(repoList);

        List<Repo> response = repoService.getRepoByNameDateLabelUser(nameDateLabelUserDTO);

        assertEquals(repoList, response);
        verify(repoDao, times(1)).getRepoByNameDateLabelUser(null,null,null,null,null);
    }


}
