package com.example.backend.serviceImpl;

import com.example.backend.dao.CommentDao;
import com.example.backend.dao.DiscussionDao;
import com.example.backend.dao.UserDao;
import com.example.backend.domains.Comment;
import com.example.backend.domains.Discussion;
import com.example.backend.domains.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class ForumServiceImplTest {

    @Mock
    private DiscussionDao discussionDao;

    @Mock
    private CommentDao commentDao;

    @Mock
    private UserDao userDao;

    @InjectMocks
    private ForumServiceImpl forumService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getCommentByDiscussion() {
        List<Comment> comments = List.of(new Comment());
        when(commentDao.findByDiscussionId(anyInt())).thenReturn(comments);

        List<Comment> result = forumService.getCommentByDiscussion(1);

        assertEquals(comments, result);
        verify(commentDao, times(1)).findByDiscussionId(1);
    }

    @Test
    void getDiscussionsByUserId() {
        User user = new User();
        List<Discussion> discussions = List.of(new Discussion());
        when(userDao.findById(anyInt())).thenReturn(Optional.of(user));
        when(discussionDao.findByInitUser(any(User.class))).thenReturn(discussions);

        List<Discussion> result = forumService.getDiscussionsByUserId(1);

        assertEquals(discussions, result);
        verify(userDao, times(1)).findById(1);
        verify(discussionDao, times(1)).findByInitUser(user);
    }

    @Test
    void getDiscussionsByUserName() {
        User user = new User();
        List<Discussion> discussions = List.of(new Discussion());
        when(userDao.getByName(anyString())).thenReturn(user);
        when(discussionDao.findByInitUser(any(User.class))).thenReturn(discussions);

        List<Discussion> result = forumService.getDiscussionsByUserName("John");

        assertEquals(discussions, result);
        verify(userDao, times(1)).getByName("John");
        verify(discussionDao, times(1)).findByInitUser(user);
    }

    @Test
    void addComment() {
        User user = new User();
        Discussion discussion = new Discussion();
        Comment comment = new Comment();
        when(userDao.findByName(anyString())).thenReturn(user);
        when(discussionDao.findById(anyInt())).thenReturn(Optional.of(discussion));
        when(commentDao.save(any(Comment.class))).thenReturn(comment);

        Comment result = forumService.addComment("John", 1, "Test content");

        assertEquals(comment, result);
        verify(userDao, times(1)).findByName("John");
        verify(discussionDao, times(1)).findById(1);
        verify(commentDao, times(1)).save(any(Comment.class));
    }

    @Test
    void createDiscussion() {
        User user = new User();
        Discussion discussion = new Discussion();
        when(userDao.getByName(anyString())).thenReturn(user);
        when(discussionDao.save(any(Discussion.class))).thenReturn(discussion);

        Discussion result = forumService.createDiscussion("John", "Test title");

        assertEquals(discussion, result);
        verify(userDao, times(1)).getByName("John");
        verify(discussionDao, times(1)).save(any(Discussion.class));
    }

    @Test
    void getCommentsByDate() {
        List<Comment> comments = List.of(new Comment());
        when(commentDao.findByDiscussionIdAndDate(anyInt(), any(Date.class))).thenReturn(comments);

        List<Comment> result = forumService.getCommentsByDate(1, new Date());

        assertEquals(comments, result);
        verify(commentDao, times(1)).findByDiscussionIdAndDate(anyInt(), any(Date.class));
    }

    @Test
    void getCommentsByDateRange() {
        List<Comment> comments = List.of(new Comment());
        when(commentDao.findByDiscussionIdAndDateBetween(anyInt(), any(Date.class), any(Date.class))).thenReturn(comments);

        List<Comment> result = forumService.getCommentsByDateRange(1, new Date(), new Date());

        assertEquals(comments, result);
        verify(commentDao, times(1)).findByDiscussionIdAndDateBetween(anyInt(), any(Date.class), any(Date.class));
    }

    @Test
    void getLastCommentByDiscussion() {
        Comment comment = new Comment();
        when(commentDao.findTopByDiscussionIdOrderByDateDesc(anyInt())).thenReturn(comment);

        Comment result = forumService.getLastCommentByDiscussion(1);

        assertEquals(comment, result);
        verify(commentDao, times(1)).findTopByDiscussionIdOrderByDateDesc(1);
    }

    @Test
    void getAllDiscussions() {
        List<Discussion> discussions = List.of(new Discussion());
        when(discussionDao.findAll()).thenReturn(discussions);

        List<Discussion> result = forumService.getAllDiscussions();

        assertEquals(discussions, result);
        verify(discussionDao, times(1)).findAll();
    }
}
