package com.example.backend.serviceImpl;

import com.example.backend.DTOs.GetRepoDTO;
import com.example.backend.DTOs.UserDTO;
import com.example.backend.dao.FolderDao;
import com.example.backend.dao.RepoDao;
import com.example.backend.dao.UserDao;
import com.example.backend.domains.Repo;
import com.example.backend.domains.User;
import com.example.backend.domains.UserAuth;
import com.example.backend.service.UserService;
import com.example.backend.utils.ImageUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.mock.web.MockMultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.FileSystems;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceImplTest {

    @Mock
    private UserDao userDao;

    @Mock
    private FolderDao folderDao;

    @Mock
    private RepoDao repoDao;

    @InjectMocks
    private UserServiceImpl userService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCheckAccount() {
        UserDTO userDTO = new UserDTO("testUser", "testPassword");
        when(userDao.getPasswordByName("testUser")).thenReturn("testPassword");

        boolean result = userService.checkAccount(userDTO);

        assertTrue(result);
        verify(userDao, times(1)).getPasswordByName("testUser");
    }

    @Test
    void testCheckAccount_Invalid() {
        UserDTO userDTO = new UserDTO("testUser", "wrongPassword");
        when(userDao.getPasswordByName("testUser")).thenReturn("testPassword");

        boolean result = userService.checkAccount(userDTO);

        assertFalse(result);
        verify(userDao, times(1)).getPasswordByName("testUser");
    }

    @Test
    void testSignUp() {
        UserDTO userDTO = new UserDTO("newUser", "newPassword");
        when(userDao.getByName("newUser")).thenReturn(null);

        boolean result = userService.signUp(userDTO);

        assertTrue(result);
        verify(userDao, times(1)).addUserAuth(any(UserAuth.class));
        verify(userDao, times(1)).addUser(any(User.class));
        verify(folderDao, times(1)).createByPath("/newUser");
    }

    @Test
    void testSignUp_ExistingUser() {
        UserDTO userDTO = new UserDTO("existingUser", "newPassword");
        when(userDao.getByName("existingUser")).thenReturn(new User());

        boolean result = userService.signUp(userDTO);

        assertFalse(result);
        verify(userDao, times(0)).addUserAuth(any(UserAuth.class));
        verify(userDao, times(0)).addUser(any(User.class));
        verify(folderDao, times(0)).createByPath(anyString());
    }

    @Test
    void testCheckStarByPath() {
        GetRepoDTO getRepoDTO = new GetRepoDTO(new UserDTO("testUser", "testPassword"),"testPath" );
        when(userService.checkAccount(getRepoDTO.getUserDTO())).thenReturn(true);
        when(repoDao.checkByPath("testPath")).thenReturn(true);
        Repo repo = new Repo();
        when(repoDao.findByPath("testPath")).thenReturn(repo);
        User user = new User();
        user.setStarRepositoryList(List.of(repo));
        when(userDao.getByName("testUser")).thenReturn(user);

        Boolean result = userService.checkStarByPath(getRepoDTO);

        assertTrue(result);
    }

    @Test
    void testChangeAvatar() {
        MockMultipartFile file = new MockMultipartFile("file", "test.jpg", "image/jpeg", "test image content".getBytes());
        MockMultipartHttpServletRequest request = new MockMultipartHttpServletRequest();
        request.addFile(file);
        User user = new User();
        when(userDao.getByName("testUser")).thenReturn(user);

        boolean result = userService.changeAvatar(request, "testUser");

        assertTrue(result);
        assertEquals("/SystemData/imgs/test.jpg", user.getAvatar());
        verify(userDao, times(1)).addUser(user);
        ImageUtils.saveFileToImage(any(MultipartFile.class), anyString());
    }

    @Test
    void testChangeIntroduction() {
        User user = new User();
        when(userDao.getByName("testUser")).thenReturn(user);

        boolean result = userService.changeIntroduction("new introduction", "testUser");

        assertTrue(result);
        assertEquals("new introduction", user.getIntroduction());
        verify(userDao, times(1)).addUser(user);
    }

    @Test
    void testGetProfile() {
        User user = new User();
        when(userDao.getByName("testUser")).thenReturn(user);

        User result = userService.getProfile("testUser");

        assertEquals(user, result);
        verify(userDao, times(1)).getByName("testUser");
    }

    @Test
    void testGetUserByName() {
        User user = new User();
        when(userDao.findByName("testUser")).thenReturn(user);

        User result = userService.getUserByName("testUser");

        assertEquals(user, result);
        verify(userDao, times(1)).findByName("testUser");
    }
}
