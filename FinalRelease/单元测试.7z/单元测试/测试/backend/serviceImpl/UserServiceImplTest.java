package com.example.backend.serviceImpl;

import com.example.backend.DTOs.GetRepoDTO;
import com.example.backend.DTOs.UserDTO;
import com.example.backend.dao.FolderDao;
import com.example.backend.dao.RepoDao;
import com.example.backend.dao.UserDao;
import com.example.backend.domains.Folder;
import com.example.backend.domains.Repo;
import com.example.backend.domains.User;
import com.example.backend.domains.UserAuth;
import com.example.backend.service.UserService;
import com.example.backend.utils.ImageUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import org.springframework.mock.web.MockMultipartFile;
import org.springframework.mock.web.MockMultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.FileSystems;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class UserServiceImplTest {

    @Mock
    private UserDao userDao;

    @Mock
    private FolderDao folderDao;

    @Mock
    private RepoDao repoDao;

    @InjectMocks
    private UserServiceImpl userService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void checkAccount() {
        UserDTO userDTO = new UserDTO("user", "pass");
        when(userDao.getPasswordByName("user")).thenReturn("pass");

        boolean result = userService.checkAccount(userDTO);

        assertTrue(result);
        verify(userDao, times(1)).getPasswordByName("user");
    }

    @Test
    void signUp() {
        UserDTO userDTO = new UserDTO("user", "pass");
        when(userDao.getByName("user")).thenReturn(null);

        boolean result = userService.signUp(userDTO);

        assertTrue(result);
        verify(userDao, times(1)).addUserAuth(any(UserAuth.class));
        verify(userDao, times(1)).addUser(any(User.class));
        verify(folderDao, times(1)).createByPath("/user");
    }

    @Test
    void checkStarByPath() {
        GetRepoDTO getRepoDTO = new GetRepoDTO();
        UserDTO userDTO = new UserDTO("user", "pass");
        getRepoDTO.setUserDTO(userDTO);
        Repo repo = new Repo();
        User user = new User();
        user.setStarRepositoryList(List.of(repo));
        when(userService.checkAccount(any(UserDTO.class))).thenReturn(true);
        when(repoDao.checkByPath(anyString())).thenReturn(true);
        when(repoDao.findByPath(anyString())).thenReturn(repo);
        when(userDao.getByName(anyString())).thenReturn(user);

        boolean result = userService.checkStarByPath(getRepoDTO);

        assertTrue(result);
        verify(repoDao, times(1)).findByPath(anyString());
        verify(userDao, times(1)).getByName(anyString());
    }

    @Test
    void changeAvatar() throws Exception {
        MockMultipartHttpServletRequest request = new MockMultipartHttpServletRequest();
        MockMultipartFile file = new MockMultipartFile("file", "test.png", "image/png", "some-image".getBytes());
        request.addFile(file);
        User user = new User();
        when(userDao.getByName(anyString())).thenReturn(user);

        boolean result = userService.changeAvatar(request, "user");

        assertTrue(result);
        verify(userDao, times(1)).addUser(user);
        verify(ImageUtils.class, times(1));
    }

    @Test
    void getProfile() {
        User user = new User();
        when(userDao.getByName(anyString())).thenReturn(user);

        User result = userService.getProfile("user");

        assertEquals(user, result);
        verify(userDao, times(1)).getByName("user");
    }

    @Test
    void changeIntroduction() {
        User user = new User();
        when(userDao.getByName(anyString())).thenReturn(user);

        boolean result = userService.changeIntroduction("new intro", "user");

        assertTrue(result);
        verify(userDao, times(1)).addUser(user);
    }

    @Test
    void getUserByName() {
        User user = new User();
        when(userDao.findByName(anyString())).thenReturn(user);

        User result = userService.getUserByName("user");

        assertEquals(user, result);
        verify(userDao, times(1)).findByName("user");
    }
}
