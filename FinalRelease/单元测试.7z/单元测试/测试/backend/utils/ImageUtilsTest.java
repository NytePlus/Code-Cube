package com.example.backend.utils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class ImageUtilsTest {

    @Mock
    private MultipartFile file;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveFileToImage_Success() throws Exception {
        String imgFilePath = "testImage.jpg";
        byte[] fileContent = "test content".getBytes();
        when(file.getBytes()).thenReturn(fileContent);

        ImageUtils.saveFileToImage(file, imgFilePath);

        try (InputStream in = new FileInputStream(imgFilePath)) {
            byte[] readContent = new byte[fileContent.length];
            in.read(readContent);
            assertArrayEquals(fileContent, readContent);
        }

        // Clean up the created file
        new java.io.File(imgFilePath).delete();
    }

    @Test
    void testSaveFileToImage_Failure() throws Exception {
        String imgFilePath = "testImage.jpg";
        when(file.getBytes()).thenThrow(new IOException("test exception"));

        ImageUtils.saveFileToImage(file, imgFilePath);

        verify(file, times(1)).getBytes();
    }
}
