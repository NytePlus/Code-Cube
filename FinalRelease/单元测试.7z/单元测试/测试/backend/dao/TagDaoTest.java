package com.example.backend.dao;

import com.example.backend.domains.Tag;
import com.example.backend.repository.TagRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class TagDaoTest {

    @Mock
    private TagRepo tagRepo;

    @InjectMocks
    private TagDao tagDao;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindOrCreateByName_TagExists() {
        Tag tag = new Tag("Java", new ArrayList<>());
        when(tagRepo.findByName(anyString())).thenReturn(tag);

        Tag result = tagDao.findOrCreateByName("Java");

        assertEquals(tag, result);
        verify(tagRepo, times(1)).findByName("Java");
        verify(tagRepo, times(0)).save(any(Tag.class));
    }

    @Test
    void testFindOrCreateByName_TagDoesNotExist() {
        when(tagRepo.findByName(anyString())).thenReturn(null);

        Tag result = tagDao.findOrCreateByName("Python");

        assertEquals("Python", result.getName());
        assertNotNull(result.getTagRepoList());
        verify(tagRepo, times(1)).findByName("Python");
        verify(tagRepo, times(1)).save(result);
    }
}
