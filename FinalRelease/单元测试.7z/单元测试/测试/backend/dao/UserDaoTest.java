package com.example.backend.dao;

import com.example.backend.domains.Repo;
import com.example.backend.domains.User;
import com.example.backend.domains.UserAuth;
import com.example.backend.repository.UserAuthRepo;
import com.example.backend.repository.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class UserDaoTest {

    @Mock
    private UserRepo userRepo;

    @Mock
    private UserAuthRepo userAuthRepo;

    @InjectMocks
    private UserDao userDao;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetPasswordByName_UserExists() {
        User user = new User();
        UserAuth userAuth = new UserAuth();
        userAuth.setPassword("password");
        user.setUserAuth(userAuth);
        when(userRepo.findByName(anyString())).thenReturn(user);

        String password = userDao.getPasswordByName("username");

        assertEquals("password", password);
        verify(userRepo, times(1)).findByName("username");
    }

    @Test
    void testGetPasswordByName_UserDoesNotExist() {
        when(userRepo.findByName(anyString())).thenReturn(null);

        String password = userDao.getPasswordByName("username");

        assertNull(password);
        verify(userRepo, times(1)).findByName("username");
    }

    @Test
    void testGetByName() {
        User user = new User();
        when(userRepo.findByName(anyString())).thenReturn(user);

        User result = userDao.getByName("username");

        assertEquals(user, result);
        verify(userRepo, times(1)).findByName("username");
    }

    @Test
    void testFindById() {
        User user = new User();
        Optional<User> optionalUser = Optional.of(user);
        when(userRepo.findById(anyInt())).thenReturn(optionalUser);

        Optional<User> result = userDao.findById(1);

        assertEquals(optionalUser, result);
        verify(userRepo, times(1)).findById(1);
    }

    @Test
    void testAddUser() {
        User user = new User();

        userDao.addUser(user);

        verify(userRepo, times(1)).save(user);
    }

    @Test
    void testAddUserAuth() {
        UserAuth userAuth = new UserAuth();

        userDao.addUserAuth(userAuth);

        verify(userAuthRepo, times(1)).save(userAuth);
    }

    @Test
    void testAddStar() {
        User user = new User();
        Repo repo = new Repo();
        user.setStarRepositoryList(new java.util.ArrayList<>());

        userDao.addStar(repo, user);

        assertTrue(user.getStarRepositoryList().contains(repo));
        verify(userRepo, times(1)).save(user);
    }

    @Test
    void testRemoveStar() {
        User user = new User();
        Repo repo = new Repo();
        List<Repo> repoList = new java.util.ArrayList<>();
        repoList.add(repo);
        user.setStarRepositoryList(repoList);

        userDao.removeStar(repo, user);

        assertFalse(user.getStarRepositoryList().contains(repo));
        verify(userRepo, times(1)).save(user);
    }

    @Test
    void testFindByName() {
        User user = new User();
        when(userRepo.findByName(anyString())).thenReturn(user);

        User result = userDao.findByName("username");

        assertEquals(user, result);
        verify(userRepo, times(1)).findByName("username");
    }
}
