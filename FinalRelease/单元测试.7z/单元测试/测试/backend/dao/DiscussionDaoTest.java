package com.example.backend.dao;

import com.example.backend.domains.Discussion;
import com.example.backend.domains.User;
import com.example.backend.repository.DiscussionRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class DiscussionDaoTest {

    @Mock
    private DiscussionRepo discussionRepo;

    @InjectMocks
    private DiscussionDao discussionDao;

    private Discussion discussion;
    private User user;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        user = new User();
        discussion = new Discussion();
        discussion.setId(1);
        discussion.setName("Test Discussion");
        discussion.setInitUser(user);
    }

    @Test
    void testFindById() {
        when(discussionRepo.findById(1)).thenReturn(Optional.of(discussion));

        Optional<Discussion> foundDiscussion = discussionDao.findById(1);

        assertEquals(discussion, foundDiscussion.orElse(null));
        verify(discussionRepo, times(1)).findById(1);
    }

    @Test
    void testFindByInitUser() {
        List<Discussion> discussions = Arrays.asList(discussion);
        when(discussionRepo.findByInitUser(user)).thenReturn(discussions);

        List<Discussion> foundDiscussions = discussionDao.findByInitUser(user);

        assertEquals(discussions, foundDiscussions);
        verify(discussionRepo, times(1)).findByInitUser(user);
    }

    @Test
    void testSave() {
        when(discussionRepo.save(any(Discussion.class))).thenReturn(discussion);

        Discussion savedDiscussion = discussionDao.save(discussion);

        assertEquals(discussion, savedDiscussion);
        verify(discussionRepo, times(1)).save(discussion);
    }

    @Test
    void testFindAll() {
        List<Discussion> discussions = Arrays.asList(discussion);
        when(discussionRepo.findAll()).thenReturn(discussions);

        List<Discussion> foundDiscussions = discussionDao.findAll();

        assertEquals(discussions, foundDiscussions);
        verify(discussionRepo, times(1)).findAll();
    }
}
