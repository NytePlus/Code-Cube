package com.example.backend.dao;

import com.example.backend.DTOs.CreateRepoDTO;
import com.example.backend.DTOs.UserDTO;
import com.example.backend.domains.Folder;
import com.example.backend.domains.Repo;
import com.example.backend.domains.Tag;
import com.example.backend.domains.User;
import com.example.backend.repository.RepoRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class RepoDaoTest {

    @Mock
    private RepoRepo repoRepo;

    @Mock
    private FolderDao folderDao;

    @Mock
    private UserDao userDao;

    @Mock
    private TagDao tagDao;

    @InjectMocks
    private RepoDao repoDao;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindByPath() {
        Repo repo = new Repo();
        when(repoRepo.findByPath(anyString())).thenReturn(repo);

        Repo result = repoDao.findByPath("path/to/repo");

        assertEquals(repo, result);
        verify(repoRepo, times(1)).findByPath("path/to/repo");
    }

    @Test
    void testCheckByPath_RepoExists() {
        when(repoRepo.findByPath(anyString())).thenReturn(new Repo());

        Boolean result = repoDao.checkByPath("path/to/repo");

        assertTrue(result);
        verify(repoRepo, times(1)).findByPath("path/to/repo");
    }

    @Test
    void testCheckByPath_RepoDoesNotExist() {
        when(repoRepo.findByPath(anyString())).thenReturn(null);

        Boolean result = repoDao.checkByPath("path/to/repo");

        assertFalse(result);
        verify(repoRepo, times(1)).findByPath("path/to/repo");
    }

    @Test
    void testCreateByRepoDTO() {
        CreateRepoDTO createRepoDTO = new CreateRepoDTO(new UserDTO("user", "password"), "path/to/repo", true, "Introduction", List.of("tag1", "tag2"));
        Folder folder = new Folder();
        User user = new User();
        Tag tag1 = new Tag("tag1", new ArrayList<>());
        Tag tag2 = new Tag("tag2", new ArrayList<>());

        when(folderDao.createByPath(anyString())).thenReturn(folder);
        when(userDao.getByName(anyString())).thenReturn(user);
        when(tagDao.findOrCreateByName("tag1")).thenReturn(tag1);
        when(tagDao.findOrCreateByName("tag2")).thenReturn(tag2);
        when(repoRepo.save(any(Repo.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Repo result = repoDao.createByRepoDTO(createRepoDTO);

        assertEquals("path/to/repo", result.getPath());
        assertEquals("repo", result.getName());
        assertEquals("Introduction", result.getIntroduction());
        assertEquals(0, result.getStar());
        assertTrue(result.isPublish());
        assertEquals(LocalDate.now().toString(), result.getDate());
        assertEquals(folder, result.getFolder());
        assertEquals(user, result.getInitUser());
        assertTrue(result.getRepoTagList().contains(tag1));
        assertTrue(result.getRepoTagList().contains(tag2));
        verify(repoRepo, times(1)).save(any(Repo.class));
    }

    @Test
    void testFindAllPublic() {
        List<Repo> repos = new ArrayList<>();
        when(repoRepo.findAllByPublish(anyBoolean())).thenReturn(repos);

        List<Repo> result = repoDao.findAllPublic();

        assertEquals(repos, result);
        verify(repoRepo, times(1)).findAllByPublish(true);
    }

    @Test
    void testFindAllByUser() {
        User user = new User();
        List<Repo> repos = new ArrayList<>();
        when(repoRepo.findAllByInitUser(any(User.class))).thenReturn(repos);

        List<Repo> result = repoDao.findAllByUser(user);

        assertEquals(repos, result);
        verify(repoRepo, times(1)).findAllByInitUser(user);
    }

    @Test
    void testAddStar() {
        Repo repo = new Repo();
        repo.setStar(10);
        when(repoRepo.save(any(Repo.class))).thenAnswer(invocation -> invocation.getArgument(0));

        repoDao.addStar(repo);

        assertEquals(11, repo.getStar());
        verify(repoRepo, times(1)).save(repo);
    }

    @Test
    void testRemoveStar() {
        Repo repo = new Repo();
        repo.setStar(10);
        when(repoRepo.save(any(Repo.class))).thenAnswer(invocation -> invocation.getArgument(0));

        repoDao.removeStar(repo);

        assertEquals(9, repo.getStar());
        verify(repoRepo, times(1)).save(repo);
    }

    @Test
    void testGetRepoByNameDateLabelUser() {
        List<Repo> repoList = new ArrayList<>();
        Repo repo1 = new Repo();
        repo1.setRepoTagList(List.of(new Tag("tag1", new ArrayList<>())));
        Repo repo2 = new Repo();
        repo2.setRepoTagList(List.of(new Tag("tag2", new ArrayList<>())));

        repoList.add(repo1);
        repoList.add(repo2);

        when(repoRepo.findByUserNameDate(anyString(), anyString(), anyString(), anyString())).thenReturn(repoList);

        List<Repo> result = repoDao.getRepoByNameDateLabelUser("name", "2023-01-01", "2023-12-31", List.of("tag1"), "user");

        assertTrue(result.contains(repo1));
        assertFalse(result.contains(repo2));
        verify(repoRepo, times(1)).findByUserNameDate("user", "name", "2023-01-01", "2023-12-31");
    }
}
