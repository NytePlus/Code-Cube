package com.example.backend.dao;

import com.example.backend.domains.File;
import com.example.backend.repository.FileRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class FileDaoTest {

    @Mock
    private FileRepo fileRepo;

    @InjectMocks
    private FileDao fileDao;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddFile() {
        File file = new File();
        fileDao.addFile(file);
        verify(fileRepo, times(1)).save(file);
    }

    @Test
    void testFindByPath_WhenFileExists() {
        String path = "/existing/file";
        File file = new File();
        when(fileRepo.findByPath(path)).thenReturn(file);

        File result = fileDao.findByPath(path);

        assertEquals(file, result);
        verify(fileRepo, times(1)).findByPath(path);
    }

    @Test
    void testFindByPath_WhenFileDoesNotExist() {
        String path = "/nonexistent/file";
        when(fileRepo.findByPath(path)).thenReturn(null);

        File result = fileDao.findByPath(path);

        assertEquals(null, result);
        verify(fileRepo, times(1)).findByPath(path);
    }

    @Test
    void testFindByPref() {
        String pathPrefix = "/some/path";
        List<File> files = Arrays.asList(new File(), new File());
        when(fileRepo.findByPref(pathPrefix)).thenReturn(files);

        List<File> result = fileDao.findByPref(pathPrefix);

        assertEquals(files, result);
        verify(fileRepo, times(1)).findByPref(pathPrefix);
    }
}
