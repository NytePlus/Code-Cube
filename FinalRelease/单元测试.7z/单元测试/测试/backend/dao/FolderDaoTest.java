package com.example.backend.dao;

import com.example.backend.domains.Folder;
import com.example.backend.repository.FolderRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FolderDaoTest {

    @Mock
    private FolderRepo folderRepo;

    @InjectMocks
    private FolderDao folderDao;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindOrCreateByPath_WhenFolderExists() {
        String path = "/existing/path";
        Folder folder = new Folder(path, "path", null, null, null);
        when(folderRepo.findByPath(path)).thenReturn(folder);

        Folder result = folderDao.findOrCreateByPath(path);

        assertEquals(folder, result);
        verify(folderRepo, times(1)).findByPath(path);
        verify(folderRepo, never()).save(any(Folder.class));
    }

    @Test
    void testFindOrCreateByPath_WhenFolderDoesNotExist() {
        String path = "/new/path";
        String parentPath = "/new";
        Folder parentFolder = new Folder(parentPath, "new", null, null, null);
        when(folderRepo.findByPath(path)).thenReturn(null);
        when(folderRepo.findByPath(parentPath)).thenReturn(parentFolder);

        Folder result = folderDao.findOrCreateByPath(path);

        assertNotNull(result);
        assertEquals(path, result.getPath());
        assertEquals("path", result.getName());
        verify(folderRepo, times(1)).findByPath(path);
        verify(folderRepo, times(1)).save(any(Folder.class));
    }

    @Test
    void testCheckByPath_WhenFolderExists() {
        String path = "/existing/path";
        when(folderRepo.findByPath(path)).thenReturn(new Folder());

        assertTrue(folderDao.checkByPath(path));
        verify(folderRepo, times(1)).findByPath(path);
    }

    @Test
    void testCheckByPath_WhenFolderDoesNotExist() {
        String path = "/nonexistent/path";
        when(folderRepo.findByPath(path)).thenReturn(null);

        assertFalse(folderDao.checkByPath(path));
        verify(folderRepo, times(1)).findByPath(path);
    }

    @Test
    void testFindByPath() {
        String path = "/some/path";
        Folder folder = new Folder();
        when(folderRepo.findByPath(path)).thenReturn(folder);

        Folder result = folderDao.findByPath(path);

        assertEquals(folder, result);
        verify(folderRepo, times(1)).findByPath(path);
    }

    @Test
    void testCreateByPath_WithEmptyPath() {
        String path = "";
        Folder folder = new Folder(path, "", new ArrayList<>(), new ArrayList<>(), null);

        Folder result = folderDao.createByPath(path);

        assertNotNull(result);
        assertEquals(path, result.getPath());
        verify(folderRepo, times(1)).save(any(Folder.class));
    }

    @Test
    void testCreateByPath_WithNonEmptyPath() {
        String path = "/new/path";
        String parentPath = "/new";
        Folder parentFolder = new Folder(parentPath, "new", null, null, null);
        when(folderRepo.findByPath(parentPath)).thenReturn(parentFolder);

        Folder result = folderDao.createByPath(path);

        assertNotNull(result);
        assertEquals(path, result.getPath());
        assertEquals("path", result.getName());
        verify(folderRepo, times(1)).save(any(Folder.class));
    }
}
