package com.example.backend.dao;

import com.example.backend.domains.Folder;
import com.example.backend.repository.FolderRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class FolderDaoTest {

    @Mock
    private FolderRepo folderRepo;

    @InjectMocks
    private FolderDao folderDao;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindOrCreateByPath_FolderExists() {
        Folder folder = new Folder();
        when(folderRepo.findByPath(anyString())).thenReturn(folder);

        Folder result = folderDao.findOrCreateByPath("existing/path");

        assertEquals(folder, result);
        verify(folderRepo, times(1)).findByPath("existing/path");
    }

    @Test
    void testFindOrCreateByPath_FolderDoesNotExist() {
        when(folderRepo.findByPath(anyString())).thenReturn(null);
        when(folderRepo.save(any(Folder.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Folder result = folderDao.findOrCreateByPath("n");

        assertEquals("n", result.getPath());
        assertEquals("path", result.getName());
        verify(folderRepo, times(1)).findByPath("n");
        verify(folderRepo, times(1)).save(any(Folder.class));
    }

    @Test
    void testCheckByPath_FolderExists() {
        when(folderRepo.findByPath(anyString())).thenReturn(new Folder());

        Boolean result = folderDao.checkByPath("existing/path");

        assertTrue(result);
        verify(folderRepo, times(1)).findByPath("existing/path");
    }

    @Test
    void testCheckByPath_FolderDoesNotExist() {
        when(folderRepo.findByPath(anyString())).thenReturn(null);

        Boolean result = folderDao.checkByPath("nonexistent/path");

        assertFalse(result);
        verify(folderRepo, times(1)).findByPath("nonexistent/path");
    }

    @Test
    void testFindByPath() {
        Folder folder = new Folder();
        when(folderRepo.findByPath(anyString())).thenReturn(folder);

        Folder result = folderDao.findByPath("existing/path");

        assertEquals(folder, result);
        verify(folderRepo, times(1)).findByPath("existing/path");
    }

    @Test
    void testCreateByPath_EmptyPath() {
        when(folderRepo.save(any(Folder.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Folder result = folderDao.createByPath("");

        assertEquals("", result.getPath());
        assertEquals("", result.getName());
        assertNull(result.getFolder());
        verify(folderRepo, times(1)).save(any(Folder.class));
    }

    @Test
    void testCreateByPath_NonEmptyPath() {
        when(folderRepo.findByPath(anyString())).thenReturn(null);
        when(folderRepo.save(any(Folder.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Folder result = folderDao.createByPath("p");

        assertEquals("p", result.getPath());
        assertEquals("path", result.getName());
        assertNotNull(result.getFolder());
        verify(folderRepo, times(1)).save(any(Folder.class));
    }
}
