package com.example.backend.dao;

import com.example.backend.domains.Comment;
import com.example.backend.repository.CommentRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

class CommentDaoTest {

    @Mock
    private CommentRepo commentRepo;

    @InjectMocks
    private CommentDao commentDao;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindByDiscussionId() {
        List<Comment> comments = new ArrayList<>();
        when(commentRepo.findByDiscussionId(anyInt())).thenReturn(comments);

        List<Comment> result = commentDao.findByDiscussionId(1);

        assertEquals(comments, result);
        verify(commentRepo, times(1)).findByDiscussionId(1);
    }

    @Test
    void testSave() {
        Comment comment = new Comment();
        comment.setContent("Test content");
        when(commentRepo.save(any(Comment.class))).thenReturn(comment);

        Comment result = commentDao.save(comment);

        assertEquals(comment, result);
        verify(commentRepo, times(1)).save(comment);
    }

    @Test
    void testSaveWithEmptyContent() {
        Comment comment = new Comment();
        comment.setContent("");

        assertThrows(IllegalArgumentException.class, () -> {
            commentDao.save(comment);
        });

        verify(commentRepo, times(0)).save(any(Comment.class));
    }

    @Test
    void testFindByDiscussionIdAndDate() {
        List<Comment> comments = new ArrayList<>();
        when(commentRepo.findByDiscussionIdAndDate(anyInt(), any(Date.class))).thenReturn(comments);

        List<Comment> result = commentDao.findByDiscussionIdAndDate(1, new Date());

        assertEquals(comments, result);
        verify(commentRepo, times(1)).findByDiscussionIdAndDate(anyInt(), any(Date.class));
    }

    @Test
    void testFindByDiscussionIdAndDateBetween() {
        List<Comment> comments = new ArrayList<>();
        when(commentRepo.findByDiscussionIdAndDateBetween(anyInt(), any(Date.class), any(Date.class))).thenReturn(comments);

        List<Comment> result = commentDao.findByDiscussionIdAndDateBetween(1, new Date(), new Date());

        assertEquals(comments, result);
        verify(commentRepo, times(1)).findByDiscussionIdAndDateBetween(anyInt(), any(Date.class), any(Date.class));
    }

    @Test
    void testFindTopByDiscussionIdOrderByDateDesc() {
        Comment comment = new Comment();
        when(commentRepo.findTopByDiscussionIdOrderByDateDesc(anyInt())).thenReturn(comment);

        Comment result = commentDao.findTopByDiscussionIdOrderByDateDesc(1);

        assertEquals(comment, result);
        verify(commentRepo, times(1)).findTopByDiscussionIdOrderByDateDesc(anyInt());
    }
}
