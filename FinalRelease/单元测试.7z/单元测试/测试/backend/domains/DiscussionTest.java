package com.example.backend.domains;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class DiscussionTest {

    private Discussion discussion;
    private Comment comment;
    private User user;

    @BeforeEach
    void setUp() {
        comment = new Comment();
        user = new User();

        discussion = new Discussion();
        discussion.setId(1);
        discussion.setName("Test Discussion");
        discussion.setInitUser(user);
        discussion.setCommentList(new ArrayList<>());
        discussion.setPartUserList(new ArrayList<>());

        discussion.getCommentList().add(comment);
        discussion.getPartUserList().add(user);
    }

    @Test
    void getId() {
        assertEquals(1, discussion.getId());
    }

    @Test
    void setId() {
        discussion.setId(2);
        assertEquals(2, discussion.getId());
    }

    @Test
    void getName() {
        assertEquals("Test Discussion", discussion.getName());
    }

    @Test
    void setName() {
        discussion.setName("New Discussion");
        assertEquals("New Discussion", discussion.getName());
    }

    @Test
    void getInitUser() {
        assertEquals(user, discussion.getInitUser());
    }

    @Test
    void setInitUser() {
        User newUser = new User();
        discussion.setInitUser(newUser);
        assertEquals(newUser, discussion.getInitUser());
    }

    @Test
    void getCommentList() {
        assertNotNull(discussion.getCommentList());
        assertEquals(1, discussion.getCommentList().size());
        assertEquals(comment, discussion.getCommentList().get(0));
    }

    @Test
    void setCommentList() {
        List<Comment> newCommentList = new ArrayList<>();
        Comment newComment = new Comment();
        newCommentList.add(newComment);
        discussion.setCommentList(newCommentList);
        assertEquals(newCommentList, discussion.getCommentList());
        assertEquals(1, discussion.getCommentList().size());
        assertEquals(newComment, discussion.getCommentList().get(0));
    }

    @Test
    void getPartUserList() {
        assertNotNull(discussion.getPartUserList());
        assertEquals(1, discussion.getPartUserList().size());
        assertEquals(user, discussion.getPartUserList().get(0));
    }

    @Test
    void setPartUserList() {
        List<User> newUserList = new ArrayList<>();
        User newUser = new User();
        newUserList.add(newUser);
        discussion.setPartUserList(newUserList);
        assertEquals(newUserList, discussion.getPartUserList());
        assertEquals(1, discussion.getPartUserList().size());
        assertEquals(newUser, discussion.getPartUserList().get(0));
    }
}
