package com.example.backend.domains;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserConversationTest {

    private UserConversation userConversation;
    private User user;
    private Conversation conversation;

    @BeforeEach
    void setUp() {
        user = new User();
        user.setId(1);
        user.setName("testUser");

        conversation = new Conversation();
        conversation.setId(1);

        userConversation = new UserConversation();
        userConversation.setId(1);
        userConversation.setUser(user);
        userConversation.setConversation(conversation);
    }

    @Test
    void getId() {
        assertEquals(1, userConversation.getId());
    }

    @Test
    void setId() {
        userConversation.setId(2);
        assertEquals(2, userConversation.getId());
    }

    @Test
    void getUser() {
        assertEquals(user, userConversation.getUser());
    }

    @Test
    void setUser() {
        User newUser = new User();
        newUser.setId(2);
        newUser.setName("newUser");
        userConversation.setUser(newUser);
        assertEquals(newUser, userConversation.getUser());
    }

    @Test
    void getConversation() {
        assertEquals(conversation, userConversation.getConversation());
    }

    @Test
    void setConversation() {
        Conversation newConversation = new Conversation();
        newConversation.setId(2);
        userConversation.setConversation(newConversation);
        assertEquals(newConversation, userConversation.getConversation());
    }
}
