package com.example.backend.domains;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class UserTest {

    private User user;
    private List<Repo> initRepositoryList;
    private List<Comment> commentList;
    private List<Message> messageList;
    private List<Repo> starRepositoryList;
    private List<Discussion> partDiscussionList;
    private List<Conversation> partConversationList;
    private UserAuth userAuth;

    @BeforeEach
    void setUp() {
        initRepositoryList = new ArrayList<>();
        commentList = new ArrayList<>();
        messageList = new ArrayList<>();
        starRepositoryList = new ArrayList<>();
        partDiscussionList = new ArrayList<>();
        partConversationList = new ArrayList<>();
        userAuth = new UserAuth();
        user = new User();
        user.setId(1);
        user.setName("testUser");
        user.setAvatar("avatarPath");
        user.setIntroduction("This is an introduction");
        user.setUserAuth(userAuth);
        user.setInitRepositoryList(initRepositoryList);
        user.setCommentList(commentList);
        user.setMessageList(messageList);
        user.setStarRepositoryList(starRepositoryList);
        user.setPartDiscussionList(partDiscussionList);
        user.setPartConversationList(partConversationList);
    }

    @Test
    void getId() {
        assertEquals(1, user.getId());
    }

    @Test
    void setId() {
        user.setId(2);
        assertEquals(2, user.getId());
    }

    @Test
    void getName() {
        assertEquals("testUser", user.getName());
    }

    @Test
    void setName() {
        user.setName("newUser");
        assertEquals("newUser", user.getName());
    }

    @Test
    void getAvatar() {
        assertEquals("avatarPath", user.getAvatar());
    }

    @Test
    void setAvatar() {
        user.setAvatar("newAvatarPath");
        assertEquals("newAvatarPath", user.getAvatar());
    }

    @Test
    void getIntroduction() {
        assertEquals("This is an introduction", user.getIntroduction());
    }

    @Test
    void setIntroduction() {
        user.setIntroduction("New introduction");
        assertEquals("New introduction", user.getIntroduction());
    }

    @Test
    void getUserAuth() {
        assertEquals(userAuth, user.getUserAuth());
    }

    @Test
    void setUserAuth() {
        UserAuth newUserAuth = new UserAuth();
        user.setUserAuth(newUserAuth);
        assertEquals(newUserAuth, user.getUserAuth());
    }

    @Test
    void getInitRepositoryList() {
        assertEquals(initRepositoryList, user.getInitRepositoryList());
    }

    @Test
    void setInitRepositoryList() {
        List<Repo> newInitRepositoryList = new ArrayList<>();
        user.setInitRepositoryList(newInitRepositoryList);
        assertEquals(newInitRepositoryList, user.getInitRepositoryList());
    }

    @Test
    void getCommentList() {
        assertEquals(commentList, user.getCommentList());
    }

    @Test
    void setCommentList() {
        List<Comment> newCommentList = new ArrayList<>();
        user.setCommentList(newCommentList);
        assertEquals(newCommentList, user.getCommentList());
    }

    @Test
    void getMessageList() {
        assertEquals(messageList, user.getMessageList());
    }

    @Test
    void setMessageList() {
        List<Message> newMessageList = new ArrayList<>();
        user.setMessageList(newMessageList);
        assertEquals(newMessageList, user.getMessageList());
    }

    @Test
    void getStarRepositoryList() {
        assertEquals(starRepositoryList, user.getStarRepositoryList());
    }

    @Test
    void setStarRepositoryList() {
        List<Repo> newStarRepositoryList = new ArrayList<>();
        user.setStarRepositoryList(newStarRepositoryList);
        assertEquals(newStarRepositoryList, user.getStarRepositoryList());
    }

    @Test
    void getPartDiscussionList() {
        assertEquals(partDiscussionList, user.getPartDiscussionList());
    }

    @Test
    void setPartDiscussionList() {
        List<Discussion> newPartDiscussionList = new ArrayList<>();
        user.setPartDiscussionList(newPartDiscussionList);
        assertEquals(newPartDiscussionList, user.getPartDiscussionList());
    }

    @Test
    void getPartConversationList() {
        assertEquals(partConversationList, user.getPartConversationList());
    }

    @Test
    void setPartConversationList() {
        List<Conversation> newPartConversationList = new ArrayList<>();
        user.setPartConversationList(newPartConversationList);
        assertEquals(newPartConversationList, user.getPartConversationList());
    }
}
