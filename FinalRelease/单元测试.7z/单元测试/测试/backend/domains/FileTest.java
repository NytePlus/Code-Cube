package com.example.backend.domains;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Blob;
import java.sql.SQLException;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FileTest {

    private File file;
    private Folder folder;
    private Blob content;

    @BeforeEach
    void setUp() {
        folder = new Folder();
        content = mock(Blob.class);

        file = new File();
        file.setPath("/test/path");
        file.setName("testFile");
        file.setType("text/plain");
        file.setSize(12345L);
        file.setContent(content);
        file.setFolder(folder);
    }

    @Test
    void getPath() {
        assertEquals("/test/path", file.getPath());
    }

    @Test
    void setPath() {
        file.setPath("/new/path");
        assertEquals("/new/path", file.getPath());
    }

    @Test
    void getName() {
        assertEquals("testFile", file.getName());
    }

    @Test
    void setName() {
        file.setName("newFile");
        assertEquals("newFile", file.getName());
    }

    @Test
    void getType() {
        assertEquals("text/plain", file.getType());
    }

    @Test
    void setType() {
        file.setType("application/json");
        assertEquals("application/json", file.getType());
    }

    @Test
    void getSize() {
        assertEquals(12345L, file.getSize());
    }

    @Test
    void setSize() {
        file.setSize(54321L);
        assertEquals(54321L, file.getSize());
    }

    @Test
    void getContent() throws SQLException {
        byte[] contentBytes = "test content".getBytes();
        when(content.getBytes(1, (int) content.length())).thenReturn(contentBytes);

        assertEquals(content, file.getContent());
    }

    @Test
    void setContent() {
        Blob newContent = mock(Blob.class);
        file.setContent(newContent);
        assertEquals(newContent, file.getContent());
    }

    @Test
    void getFolder() {
        assertEquals(folder, file.getFolder());
    }

    @Test
    void setFolder() {
        Folder newFolder = new Folder();
        file.setFolder(newFolder);
        assertEquals(newFolder, file.getFolder());
    }
}
