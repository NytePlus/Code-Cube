package com.example.backend.domains;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ConversationTest {

    private Conversation conversation;
    private Message message;
    private User user;

    @BeforeEach
    void setUp() {
        message = new Message();
        user = new User();

        conversation = new Conversation();
        conversation.setId(1);
        conversation.setMessageList(new ArrayList<>());
        conversation.setPartUserList(new ArrayList<>());

        conversation.getMessageList().add(message);
        conversation.getPartUserList().add(user);
    }

    @Test
    void getId() {
        assertEquals(1, conversation.getId());
    }

    @Test
    void setId() {
        conversation.setId(2);
        assertEquals(2, conversation.getId());
    }

    @Test
    void getMessageList() {
        assertNotNull(conversation.getMessageList());
        assertEquals(1, conversation.getMessageList().size());
        assertEquals(message, conversation.getMessageList().get(0));
    }

    @Test
    void setMessageList() {
        List<Message> newMessageList = new ArrayList<>();
        Message newMessage = new Message();
        newMessageList.add(newMessage);
        conversation.setMessageList(newMessageList);
        assertEquals(newMessageList, conversation.getMessageList());
        assertEquals(1, conversation.getMessageList().size());
        assertEquals(newMessage, conversation.getMessageList().get(0));
    }

    @Test
    void getPartUserList() {
        assertNotNull(conversation.getPartUserList());
        assertEquals(1, conversation.getPartUserList().size());
        assertEquals(user, conversation.getPartUserList().get(0));
    }

    @Test
    void setPartUserList() {
        List<User> newUserList = new ArrayList<>();
        User newUser = new User();
        newUserList.add(newUser);
        conversation.setPartUserList(newUserList);
        assertEquals(newUserList, conversation.getPartUserList());
        assertEquals(1, conversation.getPartUserList().size());
        assertEquals(newUser, conversation.getPartUserList().get(0));
    }
}
