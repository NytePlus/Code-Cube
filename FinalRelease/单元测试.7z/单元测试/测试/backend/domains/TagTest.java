package com.example.backend.domains;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TagTest {

    private Tag tag;
    private List<Repo> tagRepoList;

    @BeforeEach
    void setUp() {
        tagRepoList = new ArrayList<>();
        tag = new Tag("Java", tagRepoList);
    }
    @Test
    void testAllArgsConstructor() {
        List<Repo> newTagRepoList = new ArrayList<>();
        newTagRepoList.add(new Repo());
        Tag newTag = new Tag("C++", newTagRepoList);

        assertEquals("C++", newTag.getName());
        assertEquals(newTagRepoList, newTag.getTagRepoList());
    }

    @Test
    void getName() {
        assertEquals("Java", tag.getName());
    }

    @Test
    void setName() {
        tag.setName("Python");
        assertEquals("Python", tag.getName());
    }

    @Test
    void getTagRepoList() {
        assertEquals(tagRepoList, tag.getTagRepoList());
    }

    @Test
    void setTagRepoList() {
        List<Repo> newTagRepoList = new ArrayList<>();
        tag.setTagRepoList(newTagRepoList);
        assertEquals(newTagRepoList, tag.getTagRepoList());
    }
}
