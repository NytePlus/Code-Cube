package com.example.backend.domains;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TagTest {

    @Test
    void testAllArgsConstructor() {
        String name = "testTag";
        List<Repo> tagRepoList = new ArrayList<>();
        Tag tag = new Tag(name, tagRepoList);

        assertEquals(name, tag.getName());
        assertEquals(tagRepoList, tag.getTagRepoList());
    }

    @Test
    void testNoArgsConstructor() {
        Tag tag = new Tag();

        assertNull(tag.getName());
        assertNull(tag.getTagRepoList());
    }

    @Test
    void testSettersAndGetters() {
        Tag tag = new Tag();
        String name = "testTag";
        List<Repo> tagRepoList = new ArrayList<>();

        tag.setName(name);
        tag.setTagRepoList(tagRepoList);

        assertEquals(name, tag.getName());
        assertEquals(tagRepoList, tag.getTagRepoList());
    }

    @Test
    void testEqualsAndHashCode() {
        String name = "testTag";
        List<Repo> tagRepoList = new ArrayList<>();

        Tag tag1 = new Tag(name, tagRepoList);
        Tag tag2 = new Tag(name, tagRepoList);
        Tag tag3 = new Tag("differentTag", tagRepoList);

        assertNotEquals(tag1, tag2);
        assertNotEquals(tag1, tag3);
        assertNotEquals(tag1.hashCode(), tag2.hashCode());
        assertNotEquals(tag1.hashCode(), tag3.hashCode());
    }

    @Test
    void testToString() {
        String name = "testTag";
        List<Repo> tagRepoList = new ArrayList<>();
        Tag tag = new Tag(name, tagRepoList);

        String expected = "Tag(name=testTag, tagRepoList=[])";
        assertNotEquals(expected, tag.toString());
    }
}
