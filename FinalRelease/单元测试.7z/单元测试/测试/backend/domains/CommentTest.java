package com.example.backend.domains;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CommentTest {

    private Comment comment;
    private User user;
    private Discussion discussion;
    private Comment parentComment;

    @BeforeEach
    void setUp() {
        user = new User();
        discussion = new Discussion();
        parentComment = new Comment();

        comment = new Comment();
        comment.setId(1);
        comment.setContent("This is a comment");
        comment.setLikes(10);
        comment.setDate(new Date());
        comment.setUser(user);
        comment.setComment(parentComment);
        comment.setDiscussion(discussion);
    }

    @Test
    void getId() {
        assertEquals(1, comment.getId());
    }

    @Test
    void setId() {
        comment.setId(2);
        assertEquals(2, comment.getId());
    }

    @Test
    void getContent() {
        assertEquals("This is a comment", comment.getContent());
    }

    @Test
    void setContent() {
        comment.setContent("New content");
        assertEquals("New content", comment.getContent());
    }

    @Test
    void getLikes() {
        assertEquals(10, comment.getLikes());
    }

    @Test
    void setLikes() {
        comment.setLikes(20);
        assertEquals(20, comment.getLikes());
    }

    @Test
    void getDate() {
        assertNotNull(comment.getDate());
    }

    @Test
    void setDate() {
        Date newDate = new Date();
        comment.setDate(newDate);
        assertEquals(newDate, comment.getDate());
    }

    @Test
    void getCommentList() {
        Comment childComment = new Comment();
        comment.setCommentList(List.of(childComment));
        assertEquals(1, comment.getCommentList().size());
        assertEquals(childComment, comment.getCommentList().get(0));
    }

    @Test
    void setCommentList() {
        Comment childComment1 = new Comment();
        Comment childComment2 = new Comment();
        comment.setCommentList(List.of(childComment1, childComment2));
        assertEquals(2, comment.getCommentList().size());
        assertEquals(childComment1, comment.getCommentList().get(0));
        assertEquals(childComment2, comment.getCommentList().get(1));
    }

    @Test
    void getUser() {
        assertEquals(user, comment.getUser());
    }

    @Test
    void setUser() {
        User newUser = new User();
        comment.setUser(newUser);
        assertEquals(newUser, comment.getUser());
    }

    @Test
    void getComment() {
        assertEquals(parentComment, comment.getComment());
    }

    @Test
    void setComment() {
        Comment newParentComment = new Comment();
        comment.setComment(newParentComment);
        assertEquals(newParentComment, comment.getComment());
    }

    @Test
    void getDiscussion() {
        assertEquals(discussion, comment.getDiscussion());
    }

    @Test
    void setDiscussion() {
        Discussion newDiscussion = new Discussion();
        comment.setDiscussion(newDiscussion);
        assertEquals(newDiscussion, comment.getDiscussion());
    }
}
