package com.example.backend.domains;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class MessageTest {

    private Message message;
    private User user;
    private Conversation conversation;
    private Date date;

    @BeforeEach
    void setUp() {
        user = new User();
        conversation = new Conversation();
        date = new Date();

        message = new Message();
        message.setId(1);
        message.setContent("Test content");
        message.setDate(date);
        message.setUser(user);
        message.setConversation(conversation);
    }
    @Test
    void testAllArgsConstructor() {
        User testUser = new User();
        Conversation testConversation = new Conversation();
        Date testDate = new Date();

        Message newMessage = new Message(
                1,
                "Test content",
                testDate,
                testUser,
                testConversation
        );

        assertEquals(1, newMessage.getId());
        assertEquals("Test content", newMessage.getContent());
        assertEquals(testDate, newMessage.getDate());
        assertEquals(testUser, newMessage.getUser());
        assertEquals(testConversation, newMessage.getConversation());
    }

    @Test
    void getId() {
        assertEquals(1, message.getId());
    }

    @Test
    void setId() {
        message.setId(2);
        assertEquals(2, message.getId());
    }

    @Test
    void getContent() {
        assertEquals("Test content", message.getContent());
    }

    @Test
    void setContent() {
        message.setContent("New content");
        assertEquals("New content", message.getContent());
    }

    @Test
    void getDate() {
        assertEquals(date, message.getDate());
    }

    @Test
    void setDate() {
        Date newDate = new Date();
        message.setDate(newDate);
        assertEquals(newDate, message.getDate());
    }

    @Test
    void getUser() {
        assertEquals(user, message.getUser());
    }

    @Test
    void setUser() {
        User newUser = new User();
        message.setUser(newUser);
        assertEquals(newUser, message.getUser());
    }

    @Test
    void getConversation() {
        assertEquals(conversation, message.getConversation());
    }

    @Test
    void setConversation() {
        Conversation newConversation = new Conversation();
        message.setConversation(newConversation);
        assertEquals(newConversation, message.getConversation());
    }
}
