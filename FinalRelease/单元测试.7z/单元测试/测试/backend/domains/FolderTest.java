package com.example.backend.domains;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FolderTest {

    private Folder folder;
    private Folder parentFolder;
    private List<Folder> subFolders;
    private List<File> files;

    @BeforeEach
    void setUp() {
        parentFolder = new Folder();
        subFolders = new ArrayList<>();
        files = new ArrayList<>();

        folder = new Folder();
        folder.setPath("/test/path");
        folder.setName("testFolder");
        folder.setFolderList(subFolders);
        folder.setFileList(files);
        folder.setFolder(parentFolder);
    }

    @Test
    void getPath() {
        assertEquals("/test/path", folder.getPath());
    }

    @Test
    void setPath() {
        folder.setPath("/new/path");
        assertEquals("/new/path", folder.getPath());
    }

    @Test
    void getName() {
        assertEquals("testFolder", folder.getName());
    }

    @Test
    void setName() {
        folder.setName("newFolder");
        assertEquals("newFolder", folder.getName());
    }

    @Test
    void getFolderList() {
        assertEquals(subFolders, folder.getFolderList());
    }

    @Test
    void setFolderList() {
        List<Folder> newSubFolders = new ArrayList<>();
        folder.setFolderList(newSubFolders);
        assertEquals(newSubFolders, folder.getFolderList());
    }

    @Test
    void getFileList() {
        assertEquals(files, folder.getFileList());
    }

    @Test
    void setFileList() {
        List<File> newFiles = new ArrayList<>();
        folder.setFileList(newFiles);
        assertEquals(newFiles, folder.getFileList());
    }

    @Test
    void getFolder() {
        assertEquals(parentFolder, folder.getFolder());
    }

    @Test
    void setFolder() {
        Folder newParentFolder = new Folder();
        folder.setFolder(newParentFolder);
        assertEquals(newParentFolder, folder.getFolder());
    }
}
