package com.example.backend.domains;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RepoTest {

    private Repo repo;
    private Folder folder;
    private User initUser;
    private List<User> starUsers;
    private List<Tag> repoTagList;

    @BeforeEach
    void setUp() {
        folder = new Folder();
        initUser = new User();
        starUsers = new ArrayList<>();
        repoTagList = new ArrayList<>();

        repo = new Repo();
        repo.setPath("path/to/repo");
        repo.setName("Test Repo");
        repo.setIntroduction("This is a test repo");
        repo.setStar(10);
        repo.setPublish(true);
        repo.setDate("2024-06-19");
        repo.setFolder(folder);
        repo.setInitUser(initUser);
        repo.setStarUsers(starUsers);
        repo.setRepoTagList(repoTagList);
    }

    @Test
    void testAllArgsConstructor() {
        Folder testFolder = new Folder();
        User testUser = new User();
        List<User> testStarUsers = new ArrayList<>();
        List<Tag> testRepoTagList = new ArrayList<>();

        Repo newRepo = new Repo(
                "path/to/newRepo",
                "New Repo",
                "This is a new repo",
                15,
                true,
                "2024-06-20",
                testFolder,
                testUser,
                testStarUsers,
                testRepoTagList
        );

        assertEquals("path/to/newRepo", newRepo.getPath());
        assertEquals("New Repo", newRepo.getName());
        assertEquals("This is a new repo", newRepo.getIntroduction());
        assertEquals(15, newRepo.getStar());
        assertTrue(newRepo.isPublish());
        assertEquals("2024-06-20", newRepo.getDate());
        assertEquals(testFolder, newRepo.getFolder());
        assertEquals(testUser, newRepo.getInitUser());
        assertEquals(testStarUsers, newRepo.getStarUsers());
        assertEquals(testRepoTagList, newRepo.getRepoTagList());
    }


    @Test
    void getPath() {
        assertEquals("path/to/repo", repo.getPath());
    }

    @Test
    void setPath() {
        repo.setPath("new/path/to/repo");
        assertEquals("new/path/to/repo", repo.getPath());
    }

    @Test
    void getName() {
        assertEquals("Test Repo", repo.getName());
    }

    @Test
    void setName() {
        repo.setName("New Test Repo");
        assertEquals("New Test Repo", repo.getName());
    }

    @Test
    void getIntroduction() {
        assertEquals("This is a test repo", repo.getIntroduction());
    }

    @Test
    void setIntroduction() {
        repo.setIntroduction("New introduction");
        assertEquals("New introduction", repo.getIntroduction());
    }

    @Test
    void getStar() {
        assertEquals(10, repo.getStar());
    }

    @Test
    void setStar() {
        repo.setStar(20);
        assertEquals(20, repo.getStar());
    }

    @Test
    void isPublish() {
        assertTrue(repo.isPublish());
    }

    @Test
    void setPublish() {
        repo.setPublish(false);
        assertFalse(repo.isPublish());
    }

    @Test
    void getDate() {
        assertEquals("2024-06-19", repo.getDate());
    }

    @Test
    void setDate() {
        repo.setDate("2024-07-19");
        assertEquals("2024-07-19", repo.getDate());
    }

    @Test
    void getFolder() {
        assertEquals(folder, repo.getFolder());
    }

    @Test
    void setFolder() {
        Folder newFolder = new Folder();
        repo.setFolder(newFolder);
        assertEquals(newFolder, repo.getFolder());
    }

    @Test
    void getInitUser() {
        assertEquals(initUser, repo.getInitUser());
    }

    @Test
    void setInitUser() {
        User newUser = new User();
        repo.setInitUser(newUser);
        assertEquals(newUser, repo.getInitUser());
    }

    @Test
    void getStarUsers() {
        assertEquals(starUsers, repo.getStarUsers());
    }

    @Test
    void setStarUsers() {
        List<User> newStarUsers = new ArrayList<>();
        repo.setStarUsers(newStarUsers);
        assertEquals(newStarUsers, repo.getStarUsers());
    }

    @Test
    void getRepoTagList() {
        assertEquals(repoTagList, repo.getRepoTagList());
    }

    @Test
    void setRepoTagList() {
        List<Tag> newRepoTagList = new ArrayList<>();
        repo.setRepoTagList(newRepoTagList);
        assertEquals(newRepoTagList, repo.getRepoTagList());
    }
}
