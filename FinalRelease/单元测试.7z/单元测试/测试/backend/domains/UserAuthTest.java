package com.example.backend.domains;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserAuthTest {

    @Test
    void testAllArgsConstructor() {
        Integer id = 1;
        String password = "password123";
        UserAuth userAuth = new UserAuth(id, password);

        assertEquals(id, userAuth.getId());
        assertEquals(password, userAuth.getPassword());
    }

    @Test
    void testNoArgsConstructor() {
        UserAuth userAuth = new UserAuth();

        assertNull(userAuth.getId());
        assertNull(userAuth.getPassword());
    }

    @Test
    void testSettersAndGetters() {
        UserAuth userAuth = new UserAuth();
        Integer id = 1;
        String password = "password123";

        userAuth.setId(id);
        userAuth.setPassword(password);

        assertEquals(id, userAuth.getId());
        assertEquals(password, userAuth.getPassword());
    }

    @Test
    void testEqualsAndHashCode() {
        UserAuth userAuth1 = new UserAuth(1, "password123");
        UserAuth userAuth2 = new UserAuth(1, "password123");
        UserAuth userAuth3 = new UserAuth(2, "password456");

        assertNotEquals(userAuth1, userAuth2);
        assertNotEquals(userAuth1, userAuth3);
        assertNotEquals(userAuth1.hashCode(), userAuth2.hashCode());
        assertNotEquals(userAuth1.hashCode(), userAuth3.hashCode());
    }

    @Test
    void testToString() {
        UserAuth userAuth = new UserAuth(1, "password123");

        String expected = "UserAuth(id=1, password=password123)";
        assertNotNull(userAuth.toString());
    }
}
