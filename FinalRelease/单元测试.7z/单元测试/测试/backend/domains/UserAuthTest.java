package com.example.backend.domains;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserAuthTest {

    private UserAuth userAuth;

    @BeforeEach
    void setUp() {
        userAuth = new UserAuth();
        userAuth.setId(1);
        userAuth.setPassword("password123");
    }

    @Test
    void getId() {
        assertEquals(1, userAuth.getId());
    }

    @Test
    void setId() {
        userAuth.setId(2);
        assertEquals(2, userAuth.getId());
    }

    @Test
    void getPassword() {
        assertEquals("password123", userAuth.getPassword());
    }

    @Test
    void setPassword() {
        userAuth.setPassword("newpassword");
        assertEquals("newpassword", userAuth.getPassword());
    }
}
