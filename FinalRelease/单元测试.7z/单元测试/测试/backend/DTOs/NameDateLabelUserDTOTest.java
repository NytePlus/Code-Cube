package com.example.backend.DTOs;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class NameDateLabelUserDTOTest {

    @Test
    void testAllArgsConstructor() {
        List<String> labels = Arrays.asList("label1", "label2");
        NameDateLabelUserDTO dto = new NameDateLabelUserDTO("name", "begin", "end", "user", labels);

        assertEquals("name", dto.getName());
        assertEquals("begin", dto.getBegin());
        assertEquals("end", dto.getEnd());
        assertEquals("user", dto.getUser());
        assertEquals(labels, dto.getLabels());
    }

    @Test
    void testNoArgsConstructorAndSetters() {
        NameDateLabelUserDTO dto = new NameDateLabelUserDTO();

        dto.setName("name");
        dto.setBegin("begin");
        dto.setEnd("end");
        dto.setUser("user");
        List<String> labels = Arrays.asList("label1", "label2");
        dto.setLabels(labels);

        assertEquals("name", dto.getName());
        assertEquals("begin", dto.getBegin());
        assertEquals("end", dto.getEnd());
        assertEquals("user", dto.getUser());
        assertEquals(labels, dto.getLabels());
    }

    @Test
    void testDataAnnotation() {
        List<String> labels = Arrays.asList("label1", "label2");
        NameDateLabelUserDTO dto1 = new NameDateLabelUserDTO("name", "begin", "end", "user", labels);
        NameDateLabelUserDTO dto2 = new NameDateLabelUserDTO("name", "begin", "end", "user", labels);

        assertEquals(dto1, dto2);
        assertEquals(dto1.hashCode(), dto2.hashCode());
        assertNotNull(dto1.toString());
    }
}
