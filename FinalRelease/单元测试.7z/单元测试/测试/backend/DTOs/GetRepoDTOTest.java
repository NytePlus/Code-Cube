package com.example.backend.DTOs;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GetRepoDTOTest {

    @Test
    void testAllArgsConstructor() {
        UserDTO userDTO = new UserDTO("user", "password");
        String path = "/repo/path";
        GetRepoDTO getRepoDTO = new GetRepoDTO(userDTO, path);

        assertEquals(userDTO, getRepoDTO.getUserDTO());
        assertEquals(path, getRepoDTO.getPath());
    }

    @Test
    void testNoArgsConstructor() {
        GetRepoDTO getRepoDTO = new GetRepoDTO();

        assertNull(getRepoDTO.getUserDTO());
        assertNull(getRepoDTO.getPath());
    }

    @Test
    void testSettersAndGetters() {
        GetRepoDTO getRepoDTO = new GetRepoDTO();
        UserDTO userDTO = new UserDTO("user", "password");
        String path = "/repo/path";

        getRepoDTO.setUserDTO(userDTO);
        getRepoDTO.setPath(path);

        assertEquals(userDTO, getRepoDTO.getUserDTO());
        assertEquals(path, getRepoDTO.getPath());
    }

    @Test
    void testEqualsAndHashCode() {
        UserDTO userDTO1 = new UserDTO("user1", "password1");
        UserDTO userDTO2 = new UserDTO("user2", "password2");
        String path1 = "/repo/path1";
        String path2 = "/repo/path2";

        GetRepoDTO getRepoDTO1 = new GetRepoDTO(userDTO1, path1);
        GetRepoDTO getRepoDTO2 = new GetRepoDTO(userDTO1, path1);
        GetRepoDTO getRepoDTO3 = new GetRepoDTO(userDTO2, path2);

        assertEquals(getRepoDTO1, getRepoDTO2);
        assertNotEquals(getRepoDTO1, getRepoDTO3);
        assertEquals(getRepoDTO1.hashCode(), getRepoDTO2.hashCode());
        assertNotEquals(getRepoDTO1.hashCode(), getRepoDTO3.hashCode());
    }

    @Test
    void testToString() {
        UserDTO userDTO = new UserDTO("user", "password");
        String path = "/repo/path";
        GetRepoDTO getRepoDTO = new GetRepoDTO(userDTO, path);

        String expected = "GetRepoDTO(userDTO=UserDTO(name=user, password=password), path=/repo/path)";
        assertEquals(expected, getRepoDTO.toString());
    }
}
