package com.example.backend.DTOs;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class FileDTOTest {

    @Test
    void testAllArgsConstructor() {
        FileDTO fileDTO = new FileDTO("text/plain", "testFile.txt", "/path/to/file", "file content");

        assertEquals("text/plain", fileDTO.getType());
        assertEquals("testFile.txt", fileDTO.getName());
        assertEquals("/path/to/file", fileDTO.getPath());
        assertEquals("file content", fileDTO.getContent());
    }

    @Test
    void testGettersAndSetters() {
        FileDTO fileDTO = new FileDTO();

        fileDTO.setType("text/html");
        assertEquals("text/html", fileDTO.getType());

        fileDTO.setName("newFile.html");
        assertEquals("newFile.html", fileDTO.getName());

        fileDTO.setPath("/new/path/to/file");
        assertEquals("/new/path/to/file", fileDTO.getPath());

        fileDTO.setContent("new file content");
        assertEquals("new file content", fileDTO.getContent());
    }

    @Test
    void testNoArgsConstructor() {
        FileDTO fileDTO = new FileDTO();

        assertNull(fileDTO.getType());
        assertNull(fileDTO.getName());
        assertNull(fileDTO.getPath());
        assertNull(fileDTO.getContent());
    }
}
