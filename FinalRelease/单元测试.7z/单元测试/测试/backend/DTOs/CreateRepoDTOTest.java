package com.example.backend.DTOs;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CreateRepoDTOTest {

    private CreateRepoDTO createRepoDTO;
    private UserDTO userDTO;
    private List<String> tagNameList;

    @BeforeEach
    void setUp() {
        userDTO = new UserDTO("testUser", "password");
        tagNameList = Arrays.asList("Java", "Spring");
        createRepoDTO = new CreateRepoDTO(userDTO, "/path/to/repo", true, "This is a test repo", tagNameList);
    }

    @Test
    void testGetUser() {
        assertEquals(userDTO, createRepoDTO.getUser());
    }

    @Test
    void testSetUser() {
        UserDTO newUserDTO = new UserDTO("newUser", "newPassword");
        createRepoDTO.setUser(newUserDTO);
        assertEquals(newUserDTO, createRepoDTO.getUser());
    }

    @Test
    void testGetPath() {
        assertEquals("/path/to/repo", createRepoDTO.getPath());
    }

    @Test
    void testSetPath() {
        createRepoDTO.setPath("/new/path/to/repo");
        assertEquals("/new/path/to/repo", createRepoDTO.getPath());
    }

    @Test
    void testGetPublish() {
        assertEquals(true, createRepoDTO.getPublish());
    }

    @Test
    void testSetPublish() {
        createRepoDTO.setPublish(false);
        assertEquals(false, createRepoDTO.getPublish());
    }

    @Test
    void testGetIntroduction() {
        assertEquals("This is a test repo", createRepoDTO.getIntroduction());
    }

    @Test
    void testSetIntroduction() {
        createRepoDTO.setIntroduction("New introduction");
        assertEquals("New introduction", createRepoDTO.getIntroduction());
    }

    @Test
    void testGetTagNameList() {
        assertEquals(tagNameList, createRepoDTO.getTagNameList());
    }

    @Test
    void testSetTagNameList() {
        List<String> newTagNameList = Arrays.asList("Python", "Django");
        createRepoDTO.setTagNameList(newTagNameList);
        assertEquals(newTagNameList, createRepoDTO.getTagNameList());
    }

    @Test
    void testNoArgsConstructor() {
        CreateRepoDTO emptyCreateRepoDTO = new CreateRepoDTO();
        emptyCreateRepoDTO.setUser(userDTO);
        emptyCreateRepoDTO.setPath("/path/to/repo");
        emptyCreateRepoDTO.setPublish(true);
        emptyCreateRepoDTO.setIntroduction("This is a test repo");
        emptyCreateRepoDTO.setTagNameList(tagNameList);

        assertEquals(userDTO, emptyCreateRepoDTO.getUser());
        assertEquals("/path/to/repo", emptyCreateRepoDTO.getPath());
        assertEquals(true, emptyCreateRepoDTO.getPublish());
        assertEquals("This is a test repo", emptyCreateRepoDTO.getIntroduction());
        assertEquals(tagNameList, emptyCreateRepoDTO.getTagNameList());
    }
}
