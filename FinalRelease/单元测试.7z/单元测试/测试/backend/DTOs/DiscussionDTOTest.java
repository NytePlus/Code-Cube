package com.example.backend.DTOs;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DiscussionDTOTest {

    @Test
    void testAllArgsConstructor() {
        Integer id = 1;
        String name = "Test Discussion";
        Integer userId = 123;
        DiscussionDTO discussionDTO = new DiscussionDTO(id, name, userId);

        assertEquals(id, discussionDTO.getId());
        assertEquals(name, discussionDTO.getName());
        assertEquals(userId, discussionDTO.getUserId());
    }

    @Test
    void testSettersAndGetters() {
        DiscussionDTO discussionDTO = new DiscussionDTO(1, "Initial Name", 123);

        Integer newId = 2;
        String newName = "Updated Discussion";
        Integer newUserId = 456;

        discussionDTO.setId(newId);
        discussionDTO.setName(newName);
        discussionDTO.setUserId(newUserId);

        assertEquals(newId, discussionDTO.getId());
        assertEquals(newName, discussionDTO.getName());
        assertEquals(newUserId, discussionDTO.getUserId());
    }

    @Test
    void testEqualsAndHashCode() {
        DiscussionDTO discussionDTO1 = new DiscussionDTO(1, "Discussion", 123);
        DiscussionDTO discussionDTO2 = new DiscussionDTO(1, "Discussion", 123);
        DiscussionDTO discussionDTO3 = new DiscussionDTO(2, "Another Discussion", 456);

        assertEquals(discussionDTO1, discussionDTO2);
        assertNotEquals(discussionDTO1, discussionDTO3);
        assertEquals(discussionDTO1.hashCode(), discussionDTO2.hashCode());
        assertNotEquals(discussionDTO1.hashCode(), discussionDTO3.hashCode());
    }

    @Test
    void testToString() {
        DiscussionDTO discussionDTO = new DiscussionDTO(1, "Discussion", 123);

        String expected = "DiscussionDTO(id=1, name=Discussion, userId=123)";
        assertEquals(expected, discussionDTO.toString());
    }
}
