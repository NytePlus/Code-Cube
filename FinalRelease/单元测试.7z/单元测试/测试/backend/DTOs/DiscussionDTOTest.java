package com.example.backend.DTOs;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class DiscussionDTOTest {

    @Test
    void testAllArgsConstructor() {
        DiscussionDTO discussionDTO = new DiscussionDTO(1, "Test Discussion", 100);

        assertEquals(1, discussionDTO.getId());
        assertEquals("Test Discussion", discussionDTO.getName());
        assertEquals(100, discussionDTO.getUserId());
    }

    @Test
    void testGettersAndSetters() {
        DiscussionDTO discussionDTO = new DiscussionDTO(1, "Test Discussion", 100);

        discussionDTO.setId(2);
        assertEquals(2, discussionDTO.getId());

        discussionDTO.setName("Updated Discussion");
        assertEquals("Updated Discussion", discussionDTO.getName());

        discussionDTO.setUserId(200);
        assertEquals(200, discussionDTO.getUserId());
    }


}
