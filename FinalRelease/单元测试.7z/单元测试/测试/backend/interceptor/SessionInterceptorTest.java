package com.example.backend.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.servlet.HandlerInterceptor;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

class SessionInterceptorTest {

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Mock
    private HttpSession session;

    private SessionInterceptor sessionInterceptor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        sessionInterceptor = new SessionInterceptor();
    }

    @Test
    void preHandle_ShouldAllowOptionsMethod() throws Exception {
        when(request.getMethod()).thenReturn("OPTIONS");

        boolean result = sessionInterceptor.preHandle(request, response, new Object());

        assertTrue(result);
        verify(request, never()).getSession(false);
    }

    @Test
    void preHandle_ShouldAllowIfSessionExists() throws Exception {
        when(request.getMethod()).thenReturn("GET");
        when(request.getSession(false)).thenReturn(session);
        when(session.getAttribute("userId")).thenReturn("testUser");

        boolean result = sessionInterceptor.preHandle(request, response, new Object());

        assertTrue(result);
        verify(response, never()).setStatus(401);
    }

    @Test
    void preHandle_ShouldRejectIfSessionDoesNotExist() throws Exception {
        when(request.getMethod()).thenReturn("GET");
        when(request.getSession(false)).thenReturn(null);

        boolean result = sessionInterceptor.preHandle(request, response, new Object());

        assertFalse(result);
        verify(response, times(1)).setStatus(401);
    }

    @Test
    void preHandle_ShouldRejectIfSessionAttributeIsNull() throws Exception {
        when(request.getMethod()).thenReturn("GET");
        when(request.getSession(false)).thenReturn(session);
        when(session.getAttribute("userId")).thenReturn(null);

        boolean result = sessionInterceptor.preHandle(request, response, new Object());

        assertFalse(result);
        verify(response, times(1)).setStatus(401);
    }
}
